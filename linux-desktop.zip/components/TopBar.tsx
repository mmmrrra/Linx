import { useState, useEffect } from "react"
import { Moon, Sun, Wifi, Battery, Menu } from "lucide-react"

export default function TopBar({ isDarkMode, setIsDarkMode, setShowApplicationMenu }) {
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  return (
    <div className="fixed top-0 left-0 right-0 h-12 bg-gray-800 text-white flex items-center justify-between px-2 z-50">
      <button onClick={() => setShowApplicationMenu(true)} className="hover:bg-gray-700 p-2 rounded">
        <Menu size={20} />
      </button>
      <div className="flex items-center space-x-2">
        <span className="text-sm">{currentTime.toLocaleTimeString("en-US", { hour12: false })}</span>
        <Wifi size={16} />
        <Battery size={16} />
        <button onClick={() => setIsDarkMode(!isDarkMode)} className="p-1">
          {isDarkMode ? <Sun size={16} /> : <Moon size={16} />}
        </button>
      </div>
    </div>
  )
}

