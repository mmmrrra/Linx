import { useState } from "react"
import { X, Terminal, Folder, Settings, Chrome, Film, Image, Code } from "lucide-react"

export default function ApplicationMenu({
  isDarkMode,
  onClose,
  onOpenTerminal,
  onOpenFileExplorer,
  onOpenCodeEditor,
}: {
  isDarkMode: boolean
  onClose: () => void
  onOpenTerminal: () => void
  onOpenFileExplorer: () => void
  onOpenCodeEditor?: () => void
}) {
  const [activeApp, setActiveApp] = useState<string | null>(null)

  const simulateAppLaunch = (appName: string) => {
    setActiveApp(appName)
    setTimeout(() => {
      setActiveApp(null)
      onClose()
    }, 2000)
  }

  const apps = [
    { name: "Firefox", icon: Chrome, onClick: () => simulateAppLaunch("Firefox") },
    { name: "Terminal", icon: Terminal, onClick: onOpenTerminal },
    { name: "Settings", icon: Settings, onClick: () => simulateAppLaunch("Settings") },
    { name: "Files", icon: Folder, onClick: onOpenFileExplorer },
    { name: "VLC", icon: Film, onClick: () => simulateAppLaunch("VLC") },
    { name: "GIMP", icon: Image, onClick: () => simulateAppLaunch("GIMP") },
    { name: "VS Code", icon: Code, onClick: onOpenCodeEditor || (() => simulateAppLaunch("VS Code")) },
  ]

  return (
    <div
      className={`fixed top-12 left-0 right-0 bottom-0 ${
        isDarkMode ? "bg-gray-800 text-white" : "bg-white text-black"
      } border-t border-gray-600 shadow-lg overflow-hidden transition-all duration-300 ease-in-out`}
    >
      <div className="flex justify-between items-center p-2 bg-gray-700 text-white">
        <span className="text-sm">Applications</span>
        <button onClick={onClose}>
          <X size={16} />
        </button>
      </div>
      <div className="p-4 grid grid-cols-3 gap-4">
        {apps.map((app, index) => (
          <button
            key={index}
            className={`flex flex-col items-center p-2 rounded ${
              activeApp === app.name ? "bg-blue-500" : "hover:bg-gray-700"
            }`}
            onClick={app.onClick}
            disabled={activeApp !== null}
          >
            <app.icon size={24} />
            <span className="text-xs mt-1">{activeApp === app.name ? "Opening..." : app.name}</span>
          </button>
        ))}
      </div>
      {activeApp && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white text-black p-4 rounded">
            <p>Opening {activeApp}...</p>
          </div>
        </div>
      )}
    </div>
  )
}

