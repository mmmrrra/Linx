import { useState } from "react"
import { Play, Save, Folder, Settings, X } from "lucide-react"

export default function CodeEditor({ isDarkMode, onClose }) {
  const [code, setCode] = useState('# Write your Python code here\nprint("Hello, World!")')
  const [output, setOutput] = useState("")
  const [fileName, setFileName] = useState("untitled.py")

  const runCode = () => {
    setOutput("Running code...")
    setTimeout(() => {
      let result = ""
      const lines = code.split("\n")
      for (const line of lines) {
        if (line.startsWith("print(")) {
          const content = line.slice(6, -1).replace(/"/g, "")
          result += content + "\n"
        }
      }
      setOutput(result || "No output")
    }, 1000)
  }

  const saveCode = () => {
    setOutput(`Saving ${fileName}...`)
    setTimeout(() => setOutput(`${fileName} saved successfully.`), 1000)
  }

  return (
    <div className={`fixed inset-0 ${isDarkMode ? "bg-gray-900 text-white" : "bg-white text-black"} flex flex-col`}>
      <div className="flex justify-between items-center p-2 bg-gray-800 text-white">
        <div className="flex items-center">
          <input
            value={fileName}
            onChange={(e) => setFileName(e.target.value)}
            className="bg-transparent border-b border-gray-600 mr-4 px-2"
          />
          <button onClick={saveCode} className="mr-2 hover:text-blue-400">
            <Save size={18} />
          </button>
          <button className="mr-2 hover:text-yellow-400">
            <Folder size={18} />
          </button>
          <button className="hover:text-green-400">
            <Settings size={18} />
          </button>
        </div>
        <button onClick={onClose} className="hover:text-red-400">
          <X size={20} />
        </button>
      </div>
      <div className="flex-grow flex">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className={`flex-grow p-2 font-mono text-sm ${isDarkMode ? "bg-gray-800 text-white" : "bg-gray-100 text-black"}`}
        />
      </div>
      <div className="flex justify-between items-center p-2 bg-gray-700">
        <button
          onClick={runCode}
          className="flex items-center bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
        >
          <Play size={16} className="mr-2" />
          Run
        </button>
      </div>
      <div
        className={`h-1/4 p-2 font-mono text-sm ${isDarkMode ? "bg-black text-green-400" : "bg-gray-200 text-black"} overflow-auto`}
      >
        <pre>{output}</pre>
      </div>
    </div>
  )
}

