import { Folder, Terminal, Code } from "lucide-react"

export default function Desktop({ children, isDarkMode, onOpenFileExplorer, onOpenTerminal, onOpenCodeEditor }) {
  const desktopIcons = [
    { name: "Documents", icon: Folder, onClick: onOpenFileExplorer },
    { name: "Terminal", icon: Terminal, onClick: onOpenTerminal },
    { name: "Code Editor", icon: Code, onClick: onOpenCodeEditor },
  ]

  return (
    <div
      className={`min-h-screen pt-12 ${
        isDarkMode ? "bg-gray-900 text-white" : "bg-blue-100 text-black"
      } transition-colors duration-300 relative`}
    >
      <div className="absolute top-14 left-4 grid gap-4">
        {desktopIcons.map((icon, index) => (
          <button
            key={index}
            className="flex flex-col items-center p-2 rounded hover:bg-gray-800 hover:bg-opacity-50"
            onClick={icon.onClick}
          >
            <icon.icon size={32} />
            <span className="text-xs mt-1">{icon.name}</span>
          </button>
        ))}
      </div>
      {children}
    </div>
  )
}

