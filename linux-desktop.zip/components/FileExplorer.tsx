import { useState } from "react"
import { X, Folder } from "lucide-react"

export default function FileExplorer({ isDarkMode, onClose }) {
  const [files] = useState(["Documents", "Downloads", "Pictures", "Videos"])

  return (
    <div
      className={`fixed top-14 left-2 right-2 h-80 ${isDarkMode ? "bg-gray-800 text-white" : "bg-white text-black"} border border-gray-600 rounded shadow-lg overflow-hidden`}
    >
      <div className="flex justify-between items-center p-2 bg-gray-700 text-white">
        <span className="text-sm">File Explorer</span>
        <button onClick={onClose}>
          <X size={16} />
        </button>
      </div>
      <div className="p-2">
        {files.map((file, index) => (
          <div key={index} className="flex items-center p-2 hover:bg-gray-700 cursor-move">
            <Folder size={16} className="mr-2" />
            <span className="text-sm">{file}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

