import { useState, useEffect } from "react"
import { X } from "lucide-react"

export default function Terminal({ isDarkMode, onClose }) {
  const [command, setCommand] = useState("")
  const [output, setOutput] = useState("")

  const simulateCommand = () => {
    setOutput("Simulating command execution...")
    setTimeout(() => {
      setOutput("Command executed successfully.")
    }, 2000)
  }

  useEffect(() => {
    const typingEffect = async () => {
      const text = "user@linux:~$ sudo apt update"
      for (let i = 0; i < text.length; i++) {
        await new Promise((resolve) => setTimeout(resolve, 50))
        setCommand(text.slice(0, i + 1))
      }
      simulateCommand()
    }
    typingEffect()
  }, [simulateCommand]) // Added simulateCommand to dependencies

  return (
    <div
      className={`fixed top-14 left-2 right-2 h-64 ${isDarkMode ? "bg-black text-green-400" : "bg-white text-black"} border border-gray-600 rounded shadow-lg overflow-hidden`}
    >
      <div className="flex justify-between items-center p-2 bg-gray-800 text-white">
        <span className="text-sm">Terminal</span>
        <button onClick={onClose}>
          <X size={16} />
        </button>
      </div>
      <div className="p-2 font-mono text-xs">
        <div>{command}</div>
        <div>{output}</div>
      </div>
    </div>
  )
}

