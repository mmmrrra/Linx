"use client"

import { useState, useEffect } from "react"
import TopBar from "@/components/TopBar"
import Desktop from "@/components/Desktop"
import Terminal from "@/components/Terminal"
import FileExplorer from "@/components/FileExplorer"
import ApplicationMenu from "@/components/ApplicationMenu"
import CodeEditor from "@/components/CodeEditor"

export default function LinuxDesktop() {
  const [isDarkMode, setIsDarkMode] = useState(true)
  const [showTerminal, setShowTerminal] = useState(false)
  const [showFileExplorer, setShowFileExplorer] = useState(false)
  const [showApplicationMenu, setShowApplicationMenu] = useState(false)
  const [showCodeEditor, setShowCodeEditor] = useState(true)

  useEffect(() => {
    const darkModeClass = isDarkMode ? "dark" : ""
    document.documentElement.className = darkModeClass
  }, [isDarkMode])

  return (
    <div className={`min-h-screen ${isDarkMode ? "dark" : ""}`}>
      <Desktop isDarkMode={isDarkMode}>
        <TopBar isDarkMode={isDarkMode} setIsDarkMode={setIsDarkMode} setShowApplicationMenu={setShowApplicationMenu} />
        <div className="flex-grow flex">
          {showCodeEditor && <CodeEditor isDarkMode={isDarkMode} onClose={() => setShowCodeEditor(false)} />}
          {showTerminal && <Terminal isDarkMode={isDarkMode} onClose={() => setShowTerminal(false)} />}
          {showFileExplorer && <FileExplorer isDarkMode={isDarkMode} onClose={() => setShowFileExplorer(false)} />}
        </div>
        {showApplicationMenu && (
          <ApplicationMenu
            isDarkMode={isDarkMode}
            onClose={() => setShowApplicationMenu(false)}
            onOpenTerminal={() => setShowTerminal(true)}
            onOpenFileExplorer={() => setShowFileExplorer(true)}
            onOpenCodeEditor={() => setShowCodeEditor(true)}
          />
        )}
      </Desktop>
    </div>
  )
}

